.Include</etc/e2guardian/common.story>
.Include</etc/e2guardian/site.story>

function(checkblanketblock)
if(true,,502) return setblock

function(sslcheckblanketblock)
if(true,,506) return setblock
